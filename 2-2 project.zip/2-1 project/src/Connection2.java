
import java.sql.*;



public class Connection2 {
     Connection c;
     Statement s;
       Connection2 ()
       {
           try{
          c= (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity","root","1234");
          s=c.createStatement();
           }catch(Exception e)
           {e.printStackTrace();}
       }
}
