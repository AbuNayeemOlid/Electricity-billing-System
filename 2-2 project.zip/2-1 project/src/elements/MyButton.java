/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elements;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyButton extends JButton {

    // Constructor to create the button with default text
    public MyButton(String text) {
        super(text);  // Set button text
        initializeButton();
    }

    // Constructor to create the button without text (if needed)
    public MyButton() {
        super();  // Empty button (can add text later)
        initializeButton();
    }

    // Method to initialize the button styles
    private void initializeButton() {
        // Set default CSS-like styles
        setFocusPainted(false);
        setContentAreaFilled(false); // Make the button's content area transparent
        setBorderPainted(false);     // Remove the border
        setOpaque(false);            // Ensure the button is fully transparent
        setForeground(Color.WHITE);  // Text color
        setFont(new Font("Arial", Font.BOLD, 16)); // Font style and size

        // Add hover effect
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setForeground(Color.RED);  // Change text color on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setForeground(Color.WHITE);  // Revert text color after hover
            }
        });
    }

    // Override the paintComponent method to draw an oval button
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        int width = getWidth();
        int height = getHeight();

        // Enable anti-aliasing for smooth edges
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Set the background color for the oval
        g2.setColor(new Color(52, 152, 219)); // Background color
        g2.fillRoundRect(0, 0, width, height, height, height); // Oval effect with rounded corners

        super.paintComponent(g);
    }

    // Override the paintBorder method to ensure the border fits the oval shape
    @Override
    protected void paintBorder(Graphics g) {
        // Do not paint any border, leaving the button with only the oval shape
    }

    // Override the contains method to define the button's clickable region as oval
    @Override
    public boolean contains(int x, int y) {
        int width = getWidth();
        int height = getHeight();

        // Define an oval boundary for the button
        double ellipseX = width / 2.0;
        double ellipseY = height / 2.0;
        double radiusX = width / 2.0;
        double radiusY = height / 2.0;

        return Math.pow(x - ellipseX, 2) / Math.pow(radiusX, 2) + Math.pow(y - ellipseY, 2) / Math.pow(radiusY, 2) <= 1.0;
    }
}
