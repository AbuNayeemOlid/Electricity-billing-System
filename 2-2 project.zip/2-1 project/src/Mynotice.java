import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Mynotice extends JFrame {
    private JTextArea noticeTextArea;
    private JButton saveButton;
    private JButton editButton;

    private static final String NOTICE_FILE = "notice.txt";

    public Mynotice() {
       
        setTitle("Add/Edit Notice");
        setSize(800, 600);
       
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLocationRelativeTo(null); 

               noticeTextArea = new JTextArea(15, 40);
         noticeTextArea.setFont(new java.awt.Font("Century", 1, 24));
        JScrollPane scrollPane = new JScrollPane(noticeTextArea);

      
        saveButton = new JButton("Save");
        editButton = new JButton("Load Existing Notice");
          saveButton.setBackground(new java.awt.Color(102, 102, 255));
        saveButton.setFont(new java.awt.Font("Leelawadee", 1, 24)); // NOI18N
         editButton.setBackground(new java.awt.Color(102, 102, 255));
        editButton.setFont(new java.awt.Font("Leelawadee", 1, 24));
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(editButton);
          
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Adds padding
        mainPanel.add(new JLabel("Enter Notice:"), BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

       
        add(mainPanel);

        
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveNotice();
            }
        });

        
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadNotice();
            }
        });
    }

    
    private void saveNotice() {
        String notice = noticeTextArea.getText();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(NOTICE_FILE))) {
            writer.write(notice);
            JOptionPane.showMessageDialog(this, "Notice Saved Successfully");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving notice: " + ex.getMessage());
        }
    }

   
    private void loadNotice() {
        try (BufferedReader reader = new BufferedReader(new FileReader(NOTICE_FILE))) {
            StringBuilder notice = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                notice.append(line).append("\n");
            }
            noticeTextArea.setText(notice.toString());
            JOptionPane.showMessageDialog(this, "Notice Loaded Successfully");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error loading notice: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Mynotice().setVisible(true));
    }
}

